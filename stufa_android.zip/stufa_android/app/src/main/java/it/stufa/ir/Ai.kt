package it.stufa.ir

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Chiamate all'API Anthropic con la chiave dell'utente. Da usare sempre fuori dal thread principale. */
object Ai {
    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-haiku-5-5"

    val CHAT_SYSTEM = """
        Sei l'assistente di una app che comanda una stufa a pellet Ravelli R70 con infrarossi, dal telefono.
        Dati del manuale: il telecomando ha 6 tasti; i tasti 1 e 2 regolano la temperatura ambiente da 6 a 40 °C;
        i tasti 3 e 4 regolano la potenza da 1 a 5; il tasto 5 è On/Off e va tenuto premuto per 2 secondi.
        L'app non legge lo stato reale della stufa.
        Rispondi in italiano, in modo breve e pratico. Non inventare codici IR né tempistiche: se non li conosci, dillo.
        La stufa è un apparecchio a fiamma: non suggerire accensioni senza sorveglianza.
    """.trimIndent()

    val PROFILE_SYSTEM = """
        Sei un esperto di protocolli infrarossi. Rispondi solo con JSON valido, senza testo fuori dal JSON.
        Il JSON ha una chiave "profiles" con una lista di oggetti. Ogni oggetto ha: id (testo breve),
        header (lista vuota oppure [mark, space]), bitMark, zero, one (microsecondi, tra 100 e 20000),
        msbFirst (true o false, ordine dei bit di ogni byte).
        Proponi quattro varianti plausibili, diverse da quelle già provate.
    """.trimIndent()

    val DECODE_SYSTEM = """
        Converti il testo ricevuto in un segnale infrarosso. Rispondi solo con un JSON con due chiavi:
        hz (frequenza in Hz, ad esempio 38000) e pattern (lista di impulsi in microsecondi, alternando
        accensione e pausa e partendo dall'accensione). Se il testo non contiene un segnale, rispondi con {}.
    """.trimIndent()

    /** Invia un messaggio e restituisce il testo della risposta. */
    fun ask(apiKey: String, system: String, user: String, maxTokens: Int = 800): String {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))

        val c = URL(ENDPOINT).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", apiKey)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        try {
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                .bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IOException("errore API $code: ${text.take(200)}")
            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.getString("text"))
            }
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }

    /** Estrae la prima parte JSON dalla risposta e ricava la lista di profili validi. */
    fun parseProfiles(text: String): List<Profile> {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) return emptyList()
        return try {
            val arr = JSONObject(text.substring(start, end + 1)).getJSONArray("profiles")
            (0 until arr.length()).mapNotNull { profileFromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun profileFromJson(o: JSONObject): Profile? {
        return try {
            val id = o.optString("id", "AI").replace(Regex("[;,|]"), " ").take(24).ifBlank { "AI" }
            val h = o.optJSONArray("header")
            val header = if (h == null) IntArray(0) else IntArray(h.length()) { h.getInt(it) }
            val bitMark = o.getInt("bitMark")
            val zero = o.getInt("zero")
            val one = o.getInt("one")
            val msb = o.optBoolean("msbFirst", false)
            val timesOk = (listOf(bitMark, zero, one) + header.toList()).all { it in 100..20000 }
            val headerOk = header.size == 0 || header.size == 2
            if (timesOk && headerOk) Profile(id, header, bitMark, zero, one, msb) else null
        } catch (e: Exception) {
            null
        }
    }

    /** Interpreta la risposta del modello per la conversione di un segnale. */
    fun parseIr(text: String): IrCode? {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try {
            val o = JSONObject(text.substring(start, end + 1))
            val hz = o.getInt("hz")
            val arr = o.getJSONArray("pattern")
            val pattern = IntArray(arr.length()) { arr.getInt(it) }
            if (hz in 20000..60000 && pattern.size >= 4 && pattern.all { it in 1..100000 }) {
                IrCode(hz, pattern)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
