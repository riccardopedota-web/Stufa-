package it.stufa.ir

import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cerca nel database pubblico Flipper-IRDB (GitHub) file .ir con nomi di stufe o riscaldatori.
 * Da usare sempre fuori dal thread principale.
 */
object IrDb {
    private const val REPO = "logickworkshop/Flipper-IRDB"
    private val FOLDERS = listOf("Heaters", "Fireplaces")
    private val KEYWORDS = Regex(
        "ravelli|micronova|pellet|stufa|stove|thermorossi|palazzetti|edilkamin|castelmonte|heater|fire",
        RegexOption.IGNORE_CASE
    )

    /** Elenca le cartelle, filtra i file per nome e legge i primi maxFiles. */
    fun search(maxFiles: Int = 30): List<IrEntry> {
        val files = ArrayList<Pair<String, String>>()
        for (folder in FOLDERS) {
            val arr = JSONArray(httpGet("https://api.github.com/repos/$REPO/contents/$folder"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.optString("name")
                val url = o.optString("download_url")
                if (name.endsWith(".ir", ignoreCase = true) && KEYWORDS.containsMatchIn(name) && url.isNotEmpty()) {
                    files.add(name to url)
                }
            }
        }
        val out = ArrayList<IrEntry>()
        for ((name, url) in files.take(maxFiles)) {
            out.addAll(parseFlipperIr(httpGet(url), name))
        }
        return out
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 20_000
        c.setRequestProperty("User-Agent", "StufaIR-Android")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
