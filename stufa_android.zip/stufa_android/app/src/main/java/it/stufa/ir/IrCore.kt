package it.stufa.ir

import java.util.Locale

/** Segnale pronto da inviare: frequenza in Hz e impulsi in microsecondi (mark e space alternati). */
class IrCode(val hz: Int, val pattern: IntArray)

/** Segnale trovato nel database web, nel testo incollato o nella risposta dell'AI. */
class IrEntry(val name: String, val source: String, val hz: Int, val pattern: IntArray)

/** Tempistica da provare: intestazione (mark, space, ...), tempi dei bit, ordine dei bit. */
class Profile(
    val id: String,
    val header: IntArray,
    val bitMark: Int,
    val zero: Int,
    val one: Int,
    val msbFirst: Boolean
) {
    fun serialize(): String =
        "$bitMark;$zero;$one;${if (msbFirst) 1 else 0};${header.joinToString(",")};$id"
}

fun deserializeProfile(s: String): Profile? {
    val f = s.split(";", limit = 6)
    if (f.size < 6) return null
    val bitMark = f[0].toIntOrNull() ?: return null
    val zero = f[1].toIntOrNull() ?: return null
    val one = f[2].toIntOrNull() ?: return null
    val msb = f[3] == "1"
    val header = if (f[4].isBlank()) {
        IntArray(0)
    } else {
        f[4].split(",").map { it.toIntOrNull() ?: return null }.toIntArray()
    }
    return Profile(f[5], header, bitMark, zero, one, msb)
}

val NEC_PROFILE = Profile("NEC", intArrayOf(9000, 4500), 560, 560, 1690, msbFirst = false)

// Varianti di tempistica comuni. Non sono verificate sulla stufa: servono a trovare quella giusta.
val PROFILES: List<Profile> = listOf(
    NEC_PROFILE,
    Profile("NEC, bit MSB", intArrayOf(9000, 4500), 560, 560, 1690, msbFirst = true),
    Profile("Samsung, bit LSB", intArrayOf(4500, 4500), 560, 560, 1690, msbFirst = false),
    Profile("Samsung, bit MSB", intArrayOf(4500, 4500), 560, 560, 1690, msbFirst = true),
    Profile("Senza intestazione, bit LSB", intArrayOf(), 560, 560, 1690, msbFirst = false)
)

// Byte dei comandi Micronova (articolo di k3a): intestazione FF 1E 53, fine C0
val MN_POWER = intArrayOf(0xFF, 0x1E, 0x53, 0x4A, 0x6C, 0xC0)
val MN_UP = intArrayOf(0xFF, 0x1E, 0x53, 0x6A, 0x6A, 0xC0)
val MN_DOWN = intArrayOf(0xFF, 0x1E, 0x53, 0xCA, 0x7C, 0xC0)

/** Converte i byte di un comando nel vettore di impulsi (microsecondi, mark/space alternati). */
fun encode(p: Profile, bytes: IntArray): IntArray {
    val out = ArrayList<Int>()
    p.header.forEach { out.add(it) }
    for (b in bytes) {
        for (k in 0 until 8) {
            val bit = if (p.msbFirst) (b shr (7 - k)) and 1 else (b shr k) and 1
            out.add(p.bitMark)
            out.add(if (bit == 1) p.one else p.zero)
        }
    }
    out.add(p.bitMark)
    return out.toIntArray()
}

/** Codice NEC di un file Flipper: indirizzo e comando in 4 byte, LSB first. */
fun encodeFlipperNec(addr: IntArray, cmd: IntArray): IntArray {
    val a0 = addr[0]
    val a1 = addr[1]
    val c0 = cmd[0]
    val bytes = if (a1 == 0) {
        intArrayOf(a0, a0.inv() and 0xFF, c0, c0.inv() and 0xFF)
    } else {
        intArrayOf(a0, a1, c0, c0.inv() and 0xFF) // NEC esteso: indirizzo a 16 bit
    }
    return encode(NEC_PROFILE, bytes)
}

fun hexBytes(s: String?): IntArray? {
    if (s == null) return null
    val parts = s.trim().split(Regex("\\s+")).map { it.toIntOrNull(16) ?: return null }
    if (parts.isEmpty()) return null
    return (parts + List(maxOf(0, 4 - parts.size)) { 0 }).toIntArray()
}

/**
 * Legge un file .ir di Flipper Zero (formato testo, blocchi separati da "#").
 * Riconosce i blocchi "raw" e i "parsed" con protocollo NEC.
 */
fun parseFlipperIr(text: String, source: String): List<IrEntry> {
    val out = ArrayList<IrEntry>()
    for (block in text.split(Regex("(?m)^#[ \\t]*$"))) {
        val kv = HashMap<String, String>()
        val data = StringBuilder()
        for (line in block.lines()) {
            val i = line.indexOf(':')
            if (i <= 0) continue
            val key = line.substring(0, i).trim().lowercase(Locale.ROOT)
            val value = line.substring(i + 1).trim()
            if (key == "data") data.append(' ').append(value) else kv[key] = value
        }
        val name = kv["name"] ?: continue
        when (kv["type"]?.lowercase(Locale.ROOT)) {
            "raw" -> {
                val nums = data.toString().trim().split(Regex("\\s+")).mapNotNull { it.toIntOrNull() }
                if (nums.size >= 4) {
                    out.add(IrEntry(name, source, kv["frequency"]?.toIntOrNull() ?: 38000, nums.toIntArray()))
                }
            }
            "parsed" -> {
                if (kv["protocol"]?.equals("NEC", ignoreCase = true) == true) {
                    val a = hexBytes(kv["address"])
                    val c = hexBytes(kv["command"])
                    if (a != null && c != null) out.add(IrEntry(name, source, 38000, encodeFlipperNec(a, c)))
                }
            }
        }
    }
    return out
}

/** Testo "100, 200, 300, 400" -> impulsi. Null se c'è anche un solo token non numerico. */
fun parseNums(text: String): IntArray? {
    val nums = text.split(Regex("[,;\\s]+"))
        .filter { it.isNotBlank() }
        .map { it.trim().toIntOrNull() }
    if (nums.size < 4 || nums.any { it == null || it <= 0 }) return null
    return nums.map { it!! }.toIntArray()
}

/** Formato salvato: "frequenzaHz:impulsi,impulsi,..." */
fun parseCode(s: String): IrCode? {
    val colon = s.indexOf(':')
    if (colon < 1) return null
    val hz = s.substring(0, colon).trim().toIntOrNull() ?: return null
    val pattern = parseNums(s.substring(colon + 1)) ?: return null
    return IrCode(hz, pattern)
}

fun kHz(hz: Int): String = String.format(Locale.US, "%.1f", hz / 1000.0)
