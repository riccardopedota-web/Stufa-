package it.stufa.ir

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Telecomando IR per stufa a pellet con l'emettitore IR del telefono.
 * Ogni invio di accensione o spegnimento durante il test parte da un tocco dell'utente.
 * Dati salvati solo sul telefono (SharedPreferences).
 */
class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("stufa", MODE_PRIVATE) }
    private val ir by lazy { getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager }
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var stateText: TextView
    private lateinit var tempText: TextView
    private lateinit var missingText: TextView

    private val chatHistory = ArrayList<Pair<String, String>>()

    // Test a passi: frequenza e durata, un tocco per ogni invio
    private class Probe(val profile: Profile, val hz: Int, val holdMs: Long)
    private var probes: List<Probe> = emptyList()
    private var probeIdx = 0
    @Volatile private var probeBusy = false

    // Scansione passo per passo (impulsi personalizzati)
    private var scanList: List<Int> = emptyList()
    private var scanIdx = 0
    private var scanName = POWER
    private var scanPattern: IntArray = IntArray(0)

    companion object {
        const val POWER = "power"
        const val UP = "temp_up"
        const val DOWN = "temp_down"
        const val TMIN = 6
        const val TMAX = 40
        const val DEFAULT_HOLD_MS = 2000L
        val HOLD_OPTIONS = listOf(2000L, 4000L)
        val NAMES = linkedMapOf(
            POWER to "Accendi / spegni",
            UP to "Temperatura +",
            DOWN to "Temperatura −"
        )
        // Frequenze più comuni per le stufe, provate per prime
        val COMMON_HZ = listOf(38000, 36000, 40000, 33000, 56000, 30000)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(buildUi())
        })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- interfaccia ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun c(id: Int): Int = getColor(id)

    private fun lp(w: Int, h: Int, weight: Float = 0f, top: Int = 0, side: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(side), dp(top), dp(side), 0) }

    private fun roundBg(fill: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
    }

    private fun ovalBg(fill: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
    }

    private fun rippleOf(fill: Int, radiusDp: Int): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(0x33000000), roundBg(fill, radiusDp), null)

    private fun icon(iconRes: Int, tint: Int, sizeDp: Int = 26): ImageView =
        ImageView(this).apply {
            setImageResource(iconRes)
            imageTintList = ColorStateList.valueOf(tint)
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        }

    /** Pulsante rettangolare con icona sopra e testo sotto. */
    private fun tile(iconRes: Int, label: String, fill: Int, fg: Int, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rippleOf(fill, 20)
            setPadding(dp(6), dp(10), dp(6), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            addView(icon(iconRes, fg))
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 13f
                setTextColor(fg)
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
        }

    /** Pulsante rotondo con sola icona, per + e −. */
    private fun roundIcon(iconRes: Int, fill: Int, fg: Int, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = RippleDrawable(ColorStateList.valueOf(0x33000000), ovalBg(fill), null)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            addView(icon(iconRes, fg, 28))
        }

    private fun buildUi(): LinearLayout {
        val ink = c(R.color.ink)
        val mute = c(R.color.mute)
        val surface = c(R.color.surface)
        val sand = c(R.color.sand)
        val accent = c(R.color.accent)
        val onAccent = c(R.color.on_accent)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(36), dp(22), dp(24))
        }

        // Intestazione
        root.addView(TextView(this).apply {
            text = "Stufa"
            typeface = Typeface.SERIF
            textSize = 32f
            setTextColor(ink)
        })
        root.addView(TextView(this).apply {
            text = "Telecomando a infrarossi"
            textSize = 14f
            setTextColor(mute)
            setPadding(0, dp(2), 0, dp(18))
        })

        // Scheda di stato con temperatura
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(surface, 22)
            setPadding(dp(16), dp(18), dp(16), dp(18))
        }
        stateText = TextView(this).apply {
            textSize = 15f
            setTextColor(mute)
            gravity = Gravity.CENTER
        }
        card.addView(stateText)

        val tempRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        tempRow.addView(roundIcon(R.drawable.ic_minus, sand, ink) { onTemp(-1) }, lp(dp(64), dp(64)))

        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        mid.addView(TextView(this).apply {
            text = "Temperatura impostata"
            textSize = 12f
            setTextColor(mute)
            gravity = Gravity.CENTER
        })
        tempText = TextView(this).apply {
            typeface = Typeface.SERIF
            textSize = 36f
            setTextColor(ink)
            gravity = Gravity.CENTER
        }
        mid.addView(tempText)
        tempRow.addView(mid, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        tempRow.addView(roundIcon(R.drawable.ic_plus, sand, ink) { onTemp(+1) }, lp(dp(64), dp(64)))
        card.addView(tempRow)
        root.addView(card, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Accensione e spegnimento
        root.addView(
            tile(R.drawable.ic_power, "Accendi / spegni", accent, onAccent) { onPower() },
            lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(92), top = 16)
        )

        // Funzioni secondarie
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(tile(R.drawable.ic_codes, "Codici", sand, ink) { editCodes() }, lp(0, dp(88), 1f, side = 4))
        bottom.addView(tile(R.drawable.ic_scan, "Scansione", sand, ink) { pickScan() }, lp(0, dp(88), 1f, side = 4))
        bottom.addView(tile(R.drawable.ic_chat, "Assistente", sand, ink) { openChat() }, lp(0, dp(88), 1f, side = 4))
        root.addView(bottom, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, top = 12))

        missingText = TextView(this).apply {
            textSize = 13f
            setTextColor(mute)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        }
        root.addView(missingText, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(TextView(this).apply {
            text = "Il telefono non legge lo stato reale della stufa: mostra solo l'ultimo comando inviato."
            textSize = 12f
            setTextColor(mute)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        return root
    }

    private fun refresh() {
        val on = prefs.getBoolean("on", false)
        stateText.text = "Stato stimato: " + if (on) "acceso" else "spento"
        tempText.text = "${prefs.getInt("setpoint", 20)} °C"

        val profile = mnProfile()
        val missing = NAMES.keys.count { !hasCode(it) }
        missingText.text = when {
            profile != null && missing == 0 ->
                "Test salvato: ${profile.id}, ${kHz(prefs.getInt("mn_hz", 38000))} kHz, " +
                    "${prefs.getLong("mn_hold", DEFAULT_HOLD_MS) / 1000} secondi. " +
                    "Verifica sulla stufa che i comandi rispondano."
            missing == 0 -> "Tutti i comandi sono impostati."
            else -> "Comandi mancanti: $missing. Apri «Scansione» per trovarli."
        }
    }

    // ---------- comandi ----------

    private fun onPower() {
        if (!send(POWER)) return
        prefs.edit().putBoolean("on", !prefs.getBoolean("on", false)).apply()
        refresh()
    }

    private fun onTemp(delta: Int) {
        val cur = prefs.getInt("setpoint", 20)
        val next = (cur + delta).coerceIn(TMIN, TMAX)
        if (next == cur) {
            toast("Limite raggiunto")
            return
        }
        if (!send(if (delta > 0) UP else DOWN)) return
        prefs.edit().putInt("setpoint", next).apply()
        refresh()
    }

    private fun send(name: String): Boolean {
        val emitter = ir
        if (emitter == null || !emitter.hasIrEmitter()) {
            toast("Questo telefono non ha un emettitore IR")
            return false
        }
        val manual = loadCode(name)
        val code = manual ?: mnCode(name)
        if (code == null) {
            toast("Comando non impostato: apri «Scansione» o «Codici»")
            return false
        }
        if (!supported(emitter, code.hz)) {
            toast("Frequenza ${kHz(code.hz)} kHz non supportata dal telefono")
            return false
        }
        // Accensione e spegnimento: tasto tenuto premuto per la durata del test salvato
        val holdMs = if (manual == null && name == POWER) prefs.getLong("mn_hold", DEFAULT_HOLD_MS) else 0L
        val reps = if (manual != null) prefs.getInt("rep_$name", 1) else 1
        Thread {
            try {
                if (holdMs > 0) {
                    sendHold(emitter, code.hz, code.pattern, holdMs) { false }
                } else {
                    repeat(reps) { i ->
                        emitter.transmit(code.hz, code.pattern)
                        if (i < reps - 1) Thread.sleep(100)
                    }
                }
            } catch (e: Exception) {
                ui.post { toast("Invio non riuscito") }
            }
        }.start()
        return true
    }

    /** Invia il segnale ripetutamente per holdMs, come un tasto tenuto premuto. */
    private fun sendHold(emitter: ConsumerIrManager, hz: Int, pattern: IntArray, holdMs: Long, cancelled: () -> Boolean) {
        val end = System.currentTimeMillis() + holdMs
        do {
            if (cancelled()) return
            emitter.transmit(hz, pattern)
            Thread.sleep(40)
        } while (System.currentTimeMillis() < end)
    }

    // ---------- codici ----------

    private fun editCodes() {
        val keys = NAMES.keys.toList()
        val labels = keys.map {
            (NAMES[it] ?: it) + if (hasCode(it)) "  (impostato)" else "  (da impostare)"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Codici")
            .setItems(labels) { _, i -> editOne(keys[i]) }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun editOne(name: String) {
        val code = loadCode(name)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val hzField = EditText(this).apply {
            hint = "Frequenza in kHz (es. 38)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(code?.let { kHz(it.hz) } ?: "")
        }
        val patField = EditText(this).apply {
            hint = "Impulsi in microsecondi, es. 9000,4500,560,1690,..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            setText(code?.pattern?.joinToString(",") ?: "")
        }
        val repField = EditText(this).apply {
            hint = "Ripetizioni (1-30)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("rep_$name", 1).toString())
        }
        box.addView(hzField)
        box.addView(patField)
        box.addView(repField)

        val dlg = AlertDialog.Builder(this)
            .setTitle(NAMES[name] ?: name)
            .setView(box)
            .setPositiveButton("Salva", null)
            .setNegativeButton("Annulla", null)
            .setNeutralButton("Cancella", null)
            .create()

        dlg.setOnShowListener {
            // Il pulsante "Salva" non chiude il dialogo se i dati non sono validi
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val hz = hzField.text.toString().replace(',', '.').toDoubleOrNull()?.let { (it * 1000).toInt() }
                val pattern = parseNums(patField.text.toString())
                val reps = repField.text.toString().toIntOrNull()?.coerceIn(1, 30)
                when {
                    hz == null || hz < 20000 || hz > 60000 -> toast("Frequenza tra 20 e 60 kHz")
                    pattern == null -> toast("Impulsi non validi: servono almeno 4 numeri positivi")
                    reps == null -> toast("Ripetizioni non valide")
                    else -> {
                        prefs.edit()
                            .putString("code_$name", "$hz:" + pattern.joinToString(","))
                            .putInt("rep_$name", reps)
                            .apply()
                        toast("Salvato")
                        refresh()
                        dlg.dismiss()
                    }
                }
            }
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                prefs.edit().remove("code_$name").apply()
                refresh()
                dlg.dismiss()
            }
        }
        dlg.show()
    }

    // ---------- scansione e fonti ----------

    private fun pickScan() {
        val items = arrayOf(
            "Test per frequenza e durata (2 s e 4 s)",
            "Profili proposti dall'AI",
            "Database web (Flipper-IRDB)",
            "Incolla e interpreta un segnale",
            "Impulsi personalizzati (passo per passo)",
            "Dimentica il test salvato",
            "Chiave API Anthropic"
        )
        AlertDialog.Builder(this)
            .setTitle("Scansione")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> pickProfileForTest()
                    1 -> askAiProfiles()
                    2 -> searchWebDb()
                    3 -> pasteAndDecode()
                    4 -> pickCommandForScan()
                    5 -> {
                        prefs.edit().remove("mn_profile").remove("mn_hz").remove("mn_hold").apply()
                        toast("Test dimenticato")
                        refresh()
                    }
                    6 -> askKey { toast("Chiave salvata") }
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun pickProfileForTest() {
        val labels = PROFILES.map { it.id }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Quale formato provare?")
            .setItems(labels) { _, i -> startStepScan(listOf(PROFILES[i]), "Test ${PROFILES[i].id}") }
            .setNegativeButton("Annulla", null)
            .show()
    }

    /**
     * Test a passi: per ogni frequenza (da 20 a 60 kHz, passo 1 kHz) prova 2 secondi e 4 secondi.
     * Ogni invio parte dal tocco «Invia»; poi scegli «Ha reagito» per salvare o «Prossima».
     */
    private fun startStepScan(profiles: List<Profile>, title: String) {
        val emitter = ir
        if (emitter == null || !emitter.hasIrEmitter()) {
            toast("Questo telefono non ha un emettitore IR")
            return
        }
        val ranges = emitter.carrierFrequencies
        val freqs = (20000..60000 step 1000).filter { hz ->
            ranges.any { hz >= it.minFrequency && hz <= it.maxFrequency }
        }
        if (freqs.isEmpty()) {
            toast("Il telefono non supporta frequenze utili")
            return
        }
        val ordered = COMMON_HZ.filter { it in freqs } + freqs.filter { it !in COMMON_HZ }
        probes = ordered.flatMap { hz ->
            profiles.flatMap { p -> HOLD_OPTIONS.map { d -> Probe(p, hz, d) } }
        }
        probeIdx = 0
        probeBusy = false
        showProbe(title)
    }

    private fun showProbe(title: String) {
        val emitter = ir ?: return
        val p = probes.getOrNull(probeIdx)
        if (p == null) {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("Prove finite: nessuna combinazione ha fatto reagire la stufa.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(
                "Prova ${probeIdx + 1} di ${probes.size}\n" +
                    "Frequenza: ${kHz(p.hz)} kHz\n" +
                    "Tasto tenuto premuto: ${p.holdMs / 1000} secondi\n\n" +
                    "Tocca «Invia», guarda la stufa, poi scegli."
            )
            .setPositiveButton("Invia", null)
            .setNeutralButton("Ha reagito", null)
            .setNegativeButton("Prossima", null)
            .setCancelable(true) // il tasto indietro ferma il test
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (probeBusy) return@setOnClickListener
                probeBusy = true
                Thread {
                    try {
                        sendHold(emitter, p.hz, encode(p.profile, MN_POWER), p.holdMs) { false }
                    } catch (e: Exception) {
                        ui.post { toast("Invio non riuscito") }
                    }
                    ui.post { probeBusy = false }
                }.start()
            }
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                if (probeBusy) {
                    toast("Attendi la fine dell'invio")
                    return@setOnClickListener
                }
                saveProbe(p)
                dlg.dismiss()
            }
            dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                if (probeBusy) {
                    toast("Attendi la fine dell'invio")
                    return@setOnClickListener
                }
                probeIdx++
                dlg.dismiss()
                showProbe(title)
            }
        }
        dlg.show()
    }

    private fun saveProbe(p: Probe) {
        prefs.edit()
            .putString("mn_profile", p.profile.serialize())
            .putInt("mn_hz", p.hz)
            .putLong("mn_hold", p.holdMs)
            .apply()
        toast("Salvato: ${kHz(p.hz)} kHz, ${p.holdMs / 1000} secondi")
        refresh()
    }

    private fun askAiProfiles() {
        val key = apiKey() ?: return askKey { askAiProfiles() }
        val alreadyTried = PROFILES.map { it.id } +
            (prefs.getString("ai_tried", "") ?: "").split("|").filter { it.isNotBlank() }
        toast("Chiedo all'AI nuovi profili…")
        Thread {
            try {
                val text = Ai.ask(
                    key,
                    Ai.PROFILE_SYSTEM,
                    "Stufa a pellet Micronova (Ravelli R70), telecomando IR a 38 kHz, trama di 6 byte " +
                        "FF 1E 53 .. C0. Profili già provati, da non ripetere: ${alreadyTried.joinToString(", ")}.",
                    900
                )
                val list = Ai.parseProfiles(text)
                ui.post {
                    if (list.isEmpty()) {
                        toast("L'AI non ha proposto profili validi")
                    } else {
                        prefs.edit()
                            .putString("ai_tried", (alreadyTried + list.map { it.id }).joinToString("|"))
                            .apply()
                        AlertDialog.Builder(this)
                            .setTitle("Profili proposti dall'AI")
                            .setMessage(list.joinToString("\n") { it.id })
                            .setPositiveButton("Prova") { _, _ -> startStepScan(list, "Profili AI") }
                            .setNegativeButton("Annulla", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                ui.post { toast("AI non disponibile: ${e.message}") }
            }
        }.start()
    }

    private fun searchWebDb() {
        toast("Cerco nel database web…")
        Thread {
            try {
                val list = IrDb.search()
                ui.post {
                    if (list.isEmpty()) {
                        AlertDialog.Builder(this)
                            .setTitle("Database web")
                            .setMessage(
                                "Nelle cartelle Heaters e Fireplaces di Flipper-IRDB non ho trovato file " +
                                    "con nomi di stufe a pellet. Puoi incollare un segnale o usare il test."
                            )
                            .setPositiveButton("OK", null)
                            .show()
                    } else {
                        pickEntry(list)
                    }
                }
            } catch (e: Exception) {
                ui.post { toast("Ricerca non riuscita: ${e.message}") }
            }
        }.start()
    }

    private fun pasteAndDecode() {
        val input = EditText(this).apply {
            hint = "Incolla il segnale: file .ir di Flipper, impulsi in microsecondi o testo libero"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 5
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        AlertDialog.Builder(this)
            .setTitle("Interpreta un segnale")
            .setView(input)
            .setPositiveButton("Interpreta") { _, _ ->
                val text = input.text.toString()
                val entries = parseFlipperIr(text, "incollato")
                val nums = parseNums(text)
                when {
                    entries.isNotEmpty() -> pickEntry(entries)
                    nums != null -> pickEntry(listOf(IrEntry("Segnale incollato", "incollato", 38000, nums)))
                    else -> askAiDecode(text)
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun askAiDecode(text: String) {
        val key = apiKey() ?: return askKey { askAiDecode(text) }
        toast("Interpreto il testo con l'AI…")
        Thread {
            try {
                val reply = Ai.ask(key, Ai.DECODE_SYSTEM, text.take(6000), 1500)
                val code = Ai.parseIr(reply)
                ui.post {
                    if (code == null) {
                        toast("Non riesco a ricavare un segnale valido da questo testo")
                    } else {
                        pickEntry(listOf(IrEntry("Segnale interpretato dall'AI", "AI", code.hz, code.pattern)))
                    }
                }
            } catch (e: Exception) {
                ui.post { toast("AI non disponibile: ${e.message}") }
            }
        }.start()
    }

    private fun pickEntry(entries: List<IrEntry>) {
        val labels = entries.map { "${it.name} · ${kHz(it.hz)} kHz · ${it.pattern.size} impulsi" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Scegli il segnale")
            .setItems(labels) { _, i -> pickCommandFor(entries[i]) }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun pickCommandFor(e: IrEntry) {
        val keys = NAMES.keys.toList()
        AlertDialog.Builder(this)
            .setTitle("Usalo per…")
            .setItems(keys.map { NAMES[it] ?: it }.toTypedArray()) { _, i ->
                prefs.edit().putString("code_${keys[i]}", "${e.hz}:" + e.pattern.joinToString(",")).apply()
                toast("Salvato per ${NAMES[keys[i]]}")
                refresh()
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun pickCommandForScan() {
        val keys = NAMES.keys.toList()
        AlertDialog.Builder(this)
            .setTitle("Quale comando cerchiamo?")
            .setItems(keys.map { NAMES[it] ?: it }.toTypedArray()) { _, i -> askPatternForScan(keys[i]) }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun askPatternForScan(name: String) {
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
        val patField = EditText(this).apply {
            hint = "Impulsi del comando, es. 9000,4500,560,..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        box.addView(patField)
        AlertDialog.Builder(this)
            .setTitle("Cerca frequenza")
            .setMessage("L'app prova le frequenze una alla volta: a ogni prova chiede se la stufa ha risposto.")
            .setView(box)
            .setPositiveButton("Avvia") { _, _ ->
                val pattern = parseNums(patField.text.toString())
                if (pattern == null) toast("Impulsi non validi") else startScan(name, pattern)
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun startScan(name: String, pattern: IntArray) {
        val emitter = ir
        if (emitter == null || !emitter.hasIrEmitter()) {
            toast("Questo telefono non ha un emettitore IR")
            return
        }
        val ranges = emitter.carrierFrequencies
        val all = (20000..60000 step 1000).filter { hz ->
            ranges.any { hz >= it.minFrequency && hz <= it.maxFrequency }
        }
        scanList = COMMON_HZ.filter { it in all } + all.filter { it !in COMMON_HZ }
        if (scanList.isEmpty()) {
            toast("Il telefono non supporta frequenze utili")
            return
        }
        scanName = name
        scanPattern = pattern
        scanIdx = 0
        scanStep()
    }

    private fun scanStep() {
        if (scanIdx >= scanList.size) {
            toast("Nessuna frequenza ha fatto rispondere la stufa")
            return
        }
        val hz = scanList[scanIdx]
        val emitter = ir ?: return
        val dlg = AlertDialog.Builder(this)
            .setTitle("Frequenza ${kHz(hz)} kHz")
            .setMessage(
                "Prova ${scanIdx + 1} di ${scanList.size}.\n\n" +
                    "Tocca «Invia», guarda la stufa, poi scegli. " +
                    "Premi indietro per fermare."
            )
            .setPositiveButton("Invia", null)
            .setNeutralButton("Ha reagito", null)
            .setNegativeButton("Prossima", null)
            .setCancelable(true)
            .create()
        dlg.setOnShowListener {
            // Ogni invio parte solo da un tocco su «Invia»
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (probeBusy) return@setOnClickListener
                probeBusy = true
                Thread {
                    try {
                        emitter.transmit(hz, scanPattern)
                    } catch (e: Exception) {
                        ui.post { toast("Invio non riuscito a ${kHz(hz)} kHz") }
                    }
                    ui.post { probeBusy = false }
                }.start()
            }
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                if (probeBusy) {
                    toast("Attendi la fine dell'invio")
                    return@setOnClickListener
                }
                saveScanned(hz)
                dlg.dismiss()
            }
            dlg.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                if (probeBusy) {
                    toast("Attendi la fine dell'invio")
                    return@setOnClickListener
                }
                scanIdx++
                dlg.dismiss()
                scanStep()
            }
        }
        dlg.show()
    }

    private fun saveScanned(hz: Int) {
        prefs.edit()
            .putString("code_$scanName", "$hz:" + scanPattern.joinToString(","))
            .apply()
        toast("Salvato a ${kHz(hz)} kHz")
        refresh()
    }

    // ---------- assistente AI ----------

    private fun openChat() {
        val key = apiKey() ?: return askKey { openChat() }

        val log = TextView(this).apply {
            textSize = 15f
            setTextColor(c(R.color.ink))
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val scroll = ScrollView(this).apply { addView(log) }
        val input = EditText(this).apply { hint = "Scrivi una domanda" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)))
            addView(input)
        }

        fun render() {
            log.text = if (chatHistory.isEmpty()) {
                "Chiedi quello che ti serve su stufa, codici o test."
            } else {
                chatHistory.joinToString("\n\n") { (if (it.first == "user") "Tu: " else "AI: ") + it.second }
            }
        }
        render()

        val dlg = AlertDialog.Builder(this)
            .setTitle("Assistente AI")
            .setView(box)
            .setPositiveButton("Invia", null)
            .setNegativeButton("Chiudi", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val q = input.text.toString().trim()
                if (q.isEmpty()) return@setOnClickListener
                input.setText("")
                val transcript = chatHistory.takeLast(10).joinToString("\n") {
                    (if (it.first == "user") "Utente: " else "Assistente: ") + it.second
                }
                chatHistory.add("user" to q)
                chatHistory.add("assistant" to "…")
                render()
                Thread {
                    val prompt = (if (transcript.isNotEmpty()) "Conversazione finora:\n$transcript\n\n" else "") +
                        "Domanda: $q"
                    val reply = try {
                        Ai.ask(key, Ai.CHAT_SYSTEM + "\n\n" + appContext(), prompt, 700)
                    } catch (e: Exception) {
                        "Errore: ${e.message}"
                    }
                    ui.post {
                        chatHistory[chatHistory.size - 1] = ("assistant" to reply)
                        render()
                    }
                }.start()
            }
        }
        dlg.show()
    }

    /** Stato dell'app passato all'assistente, senza dati personali. */
    private fun appContext(): String {
        val profile = mnProfile()
        val manual = NAMES.keys.filter { loadCode(it) != null }.joinToString { NAMES[it] ?: it }
        return "Stato dell'app: test salvato = " +
            (if (profile != null) {
                "${profile.id} a ${kHz(prefs.getInt("mn_hz", 38000))} kHz, " +
                    "${prefs.getLong("mn_hold", DEFAULT_HOLD_MS) / 1000} secondi"
            } else {
                "nessuno"
            }) +
            "; comandi inseriti a mano = " + manual.ifEmpty { "nessuno" } +
            "; temperatura impostata = ${prefs.getInt("setpoint", 20)} °C."
    }

    private fun apiKey(): String? = prefs.getString("ai_key", null)?.trim()?.takeIf { it.isNotEmpty() }

    private fun askKey(then: () -> Unit) {
        val input = EditText(this).apply {
            hint = "Chiave API (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        AlertDialog.Builder(this)
            .setTitle("Chiave API Anthropic")
            .setMessage("Serve per le funzioni AI. La chiave resta solo su questo telefono; le richieste sono a pagamento sul tuo account.")
            .setView(input)
            .setPositiveButton("Salva") { _, _ ->
                val k = input.text.toString().trim()
                if (k.isEmpty()) {
                    toast("Chiave vuota")
                } else {
                    prefs.edit().putString("ai_key", k).apply()
                    then()
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    // ---------- utilità ----------

    private fun mnProfile(): Profile? = prefs.getString("mn_profile", null)?.let { deserializeProfile(it) }

    private fun mnCode(name: String): IrCode? {
        val profile = mnProfile() ?: return null
        val bytes = when (name) {
            POWER -> MN_POWER
            UP -> MN_UP
            else -> MN_DOWN
        }
        return IrCode(prefs.getInt("mn_hz", 38000), encode(profile, bytes))
    }

    private fun loadCode(name: String): IrCode? =
        prefs.getString("code_$name", null)?.let { parseCode(it) }

    private fun hasCode(name: String): Boolean = loadCode(name) != null || mnCode(name) != null

    private fun supported(emitter: ConsumerIrManager, hz: Int): Boolean =
        emitter.carrierFrequencies.any { hz >= it.minFrequency && hz <= it.maxFrequency }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
