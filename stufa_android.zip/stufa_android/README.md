# Stufa IR (app Android)

Telecomando per la stufa a pellet con l'emettitore IR del telefono. Nessun ESP32 e nessun server dedicato.

## Ottenere l'APK

Nel mio ambiente non si può compilare: l'SDK Android non è scaricabile. Due strade:

**A. GitHub (consigliata)**
1. Crea un repository privato e carica il contenuto di questa cartella.
2. Scheda **Actions**: il workflow "Build APK" parte da solo. Scarica l'artefatto **stufa-ir-apk**.
3. Trasferisci l'APK sul Redmi e installalo, consentendo le fonti sconosciute.

**B. Android Studio (sul PC)**
1. Apri la cartella `stufa_android` e lascia che scarichi SDK e Gradle.
2. **Build > Build APK(s)**. Il file esce in `app/build/outputs/apk/debug/`.

## Funzioni

- **On/Off, + e −** con il valore di temperatura impostato.
- **Codici**: frequenza, impulsi e ripetizioni inseriti a mano.
- **Scansione**:
  - *Test per frequenza e durata*: scegli il formato, poi prova ogni frequenza da 20 a 60 kHz (passo 1 kHz) con il tasto tenuto premuto 2 secondi e poi 4 secondi. **Ogni invio parte dal tocco «Invia»**: guardi la stufa e scegli «Ha reagito» per salvare, oppure «Prossima».
  - *Profili proposti dall'AI*: nuove tempistiche proposte dall'AI, provate con lo stesso test a passi.
  - *Database web*: cerca nei file .ir di Flipper-IRDB (Heaters e Fireplaces) quelli con nomi di stufe.
  - *Incolla e interpreta un segnale*: file .ir di Flipper, impulsi o testo libero (con l'AI).
  - *Impulsi personalizzati*: un tasto a 41 frequenze, una alla volta.
- **Assistente**: chat sull'uso della stufa e sui risultati del test.

Il test richiede circa 82 prove per formato: a ritmo di una prova ogni 10–20 secondi sono 15–30 minuti. Tieni la stufa a vista.

## Chiave API

Le funzioni AI usano l'API Anthropic con la tua chiave, da **Scansione > Chiave API Anthropic**. La chiave resta solo sul telefono. Le richieste sono a pagamento sul tuo account. Il modello è in `Ai.kt`.

## Limiti da sapere

- **Il protocollo della R70 non è noto.** Il test cerca la combinazione giusta, ma non è garantito che esista. Se nessuna prova fa reagire la stufa, servono gli impulsi reali del telecomando originale, da catturare con un ricevitore IR (serve un microcontrollore: il telefono non riceve infrarossi).
- **Stato stimato.** Il telefono non legge la stufa: acceso/spento e temperatura sono quelli inviati dall'app.
- **Sicurezza.** È una stufa a fiamma. Ogni accensione o spegnimento durante il test parte da un tuo tocco. Non lasciare il test senza sorveglianza.
- **Non compilato qui.** Se la compilazione dà errori, mandameli e correggo.
- **Telefono.** Serve un emettitore IR (il Redmi Note 12 Pro+ ce l'ha) e la connessione per database e AI.
